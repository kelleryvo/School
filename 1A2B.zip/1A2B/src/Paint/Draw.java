package Paint;

public interface Draw {
	public abstract String drawLine();
	public abstract String drawCircle();
	
}
