package TestCases;

import static org.junit.Assert.*;

import org.junit.Test;

import Paint.Brush;
import Paint.ColourFull;

public class TestDraw {

	@Test
	public void test() {
		ColourFull c1 = new ColourFull(254,255,0);
		c1 = new Brush();
	}

}
